package com.train.hibernate;

/**
 * Address entity. @author MyEclipse Persistence Tools
 */

public class Address implements java.io.Serializable {

	// Fields

	private Long id;
	private String fname;
	private String lname;
	private String dept;
	private String phone;
	private String mobile;
	private String email;
	private String jobtitle;

	// Constructors

	/** default constructor */
	public Address() {
	}

	/** full constructor */
	public Address(String fname, String lname, String dept, String phone,
			String mobile, String email, String jobtitle) {
		this.fname = fname;
		this.lname = lname;
		this.dept = dept;
		this.phone = phone;
		this.mobile = mobile;
		this.email = email;
		this.jobtitle = jobtitle;
	}

	// Property accessors

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDept() {
		return this.dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJobtitle() {
		return this.jobtitle;
	}

	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}

}