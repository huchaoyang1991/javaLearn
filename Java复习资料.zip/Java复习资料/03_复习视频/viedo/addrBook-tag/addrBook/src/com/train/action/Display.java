package com.train.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.train.hibernate.Address;
import com.train.service.AddrService;

public class Display extends TagSupport {
	PageContext pageContext = null;
	private AddrService service;

	public AddrService getService() {
		return service;
	}

	public void setService(AddrService service) {
		this.service = service;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1814769273670201873L;

	public Display() {

	}

	@Override
	public int doEndTag() throws JspException {
		JspWriter writer = pageContext.getOut();
		BeanFactory factory = WebApplicationContextUtils
				.getRequiredWebApplicationContext(this.pageContext
						.getServletContext());
		AddrService service = (AddrService) factory.getBean("AddrService");
		List<Address> all = service.findAll();
		try {
			for (Address addr : all) {
				writer.println("<tr><td align='center'>");
				writer.println(addr.getFname());

				writer.println("</td>");
				writer.println("<td align='center' style='height: 30px;'>");
				writer.println(addr.getLname());
				writer.println("</td>");
				writer.println("<td align='center'>");
				writer.println(addr.getMobile());
				writer.println("</td>");
				writer.println("<td align='center' style='height: 30px;'>");
				writer.println(addr.getPhone());
				writer.println("</td>");
				writer.println("<td align='center'>");
				writer.println(addr.getDept());
				writer.println("</td>");
				writer.println("<td align='center'>");
				writer.println(addr.getEmail());

				writer.println("</td></tr>");

			}
		} catch (IOException ex) {

		}
		return super.doEndTag();
	}

	@Override
	public void setPageContext(PageContext pageContext) {
		this.pageContext = pageContext;
		// TODO Auto-generated method stub
		super.setPageContext(pageContext);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
