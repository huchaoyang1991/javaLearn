package com.train.action;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.train.hibernate.Address;
import com.train.service.AddrService;

public class AddrAction {
	private AddrService service;
	private List<Address> allAddrs;
	private Address addr;
	public AddrService getService() {
		return service;
	}
	public void setService(AddrService service) {
		this.service = service;
	}
	public List<Address> getAllAddrs() {
		return allAddrs;
	}
	public void setAllAddrs(List<Address> allAddrs) {
		this.allAddrs = allAddrs;
	}
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	
	public String save(){
		this.service.save(this.addr);
		this.setAllAddrs(this.service.findAll());
		return "list";
	}
	
	
	public static void main(String[] args){
		ApplicationContext ctx = new ClassPathXmlApplicationContext ("conf/applicationContext-*.xml");
		AddrAction addr = (AddrAction)ctx.getBean("AddrAction");
		addr.save();
	}

}
