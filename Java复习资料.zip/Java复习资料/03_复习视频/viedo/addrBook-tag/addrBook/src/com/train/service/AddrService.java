package com.train.service;

import java.util.List;

import com.train.hibernate.Address;
import com.train.hibernate.AddressDAO;

public class AddrService {
	private AddressDAO dao;

	public AddressDAO getDao() {
		return dao;
	}
	public void setDao(AddressDAO dao) {
		this.dao = dao;
	}
	public void save(Address transientInstance) {
		this.dao.save(transientInstance);
	}
	public List<Address> findAll(){
		return this.dao.findAll();
	}
}
